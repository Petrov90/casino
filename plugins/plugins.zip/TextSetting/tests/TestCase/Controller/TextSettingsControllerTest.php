<?php
namespace TextSetting\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use TextSetting\Controller\TextSettingsController;

/**
 * TextSetting\Controller\TextSettingsController Test Case
 */
class TextSettingsControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
