<?php
namespace Promotion\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use Promotion\Controller\PromotionsController;

/**
 * Promotion\Controller\PromotionsController Test Case
 */
class PromotionsControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
