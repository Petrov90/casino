<?php
namespace Master\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use Master\Controller\MastersController;

/**
 * Master\Controller\MastersController Test Case
 */
class MastersControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
