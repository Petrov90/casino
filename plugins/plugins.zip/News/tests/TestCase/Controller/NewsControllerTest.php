<?php
namespace News\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use News\Controller\NewsController;

/**
 * News\Controller\NewsController Test Case
 */
class NewsControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
