<?php
namespace UploadImage\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use UploadImage\Controller\UploadImagesController;

/**
 * UploadImage\Controller\UploadImagesController Test Case
 */
class UploadImagesControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
