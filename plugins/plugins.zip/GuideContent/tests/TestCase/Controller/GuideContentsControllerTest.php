<?php
namespace GuideContent\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use GuideContent\Controller\GuideContentsController;

/**
 * GuideContent\Controller\GuideContentsController Test Case
 */
class GuideContentsControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
