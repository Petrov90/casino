<?php
namespace Block\Test\TestCase\Controller;

use Block\Controller\BlocksController;
use Cake\TestSuite\IntegrationTestCase;

/**
 * Block\Controller\BlocksController Test Case
 */
class BlocksControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
