<?php
namespace Contact\Test\TestCase\Controller;

use Cake\TestSuite\IntegrationTestCase;
use Contact\Controller\ContactsController;

/**
 * Contact\Controller\ContactsController Test Case
 */
class ContactsControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
